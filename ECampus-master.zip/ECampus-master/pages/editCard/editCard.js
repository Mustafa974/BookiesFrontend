// pages/editCard/editCard.js

import {
  $wuxDialog
} from '../../wux/index';
import Toast from '../../dist/toast/toast';

const app = getApp()
const util = require('../../utils/util.js')

Page({

  data: {
    groupId: '',
    inputInfo: {
      'inputTitle': '',
      'inputSport': '',
      'inputDate': '',
      'inputNumber': '',
      'inputDescription': '',
      // 显示的地点
      'inputLocation': ''
    },
    value: {
      'campus': '',
      'venue': '',
      'startTime': '',
      'endTime': ''
    },

    currentnum: 1,

    // Picker03 04
    show03: false,
    show04: false
  },

  // when pages loads
  onLoad: function(options) {
    var that = this
    console.log("options: ", options)
    // 加载已有的卡片数据
    wx.request({
      url: 'http://101.132.69.33:2333/getGroupDetail/getGroupDetail/' + app.globalData.openId + '/' + options.groupId,
      success: res => {
        var data = res.data
        console.log("查询组团：", data)
        // 数据渲染到本地
        that.setData({
          'groupId': options.groupId,
          'value.campus': data.campus,
          'inputInfo.inputDescription': data.comments,
          'value.endTime': data.endTime,
          'inputInfo.inputNumber': data.numOfPeople,
          'inputInfo.inputSport': data.sport,
          'value.startTime': data.startTime,
          'inputInfo.inputTitle': data.title,
          'value.venue': data.venue,
          'inputInfo.inputDate': data.date,
          'inputInfo.inputLocation': data.campus + data.venue,
          'currentnum': data.numOfMember
        })
      }
    })
  },

  // 删除按钮响应
  onDelete() {
    var that = this
    $wuxDialog().confirm({
      resetOnClose: true,
      closable: true,
      title: '删除组团',
      content: '确定删除该组团活动？',
      onConfirm(e) {
        // 发送删除请求
        wx.request({
          url: 'http://101.132.69.33:2333/group/deleteGroup/' + that.data.groupId,
          method: 'DELETE',
          success: res => {
            console.log("删除组团：", res)
            if (res.statusCode == 200) {
              if(res.data.response!="删除失败"){
                Toast({
                  duration: 1300,
                  message: '删除成功！',
                });
                // 返回页面
                setTimeout(function () {
                  wx.navigateBack({
                    delta: 2
                  })
                }, 1400);
              }
              else{
                Toast({
                  duration: 1300,
                  message: '活动正在进行，不能删除了哦',
                });
              }           
            } else {
              Toast({
                duration: 1300,
                message: '服务器繁忙，请稍后再试！',
              });
            }
          }
        })
      },
      onCancel(e) {
        // console.log('取消操作')
      },
    })
  },

  // 发布按钮响应
  onPublish: function() {
    var that = this
    console.log("表单信息：", app.globalData.openId, that.data.inputInfo, that.data.value)
    // 判断表单信息是否完善
    if (app.globalData.openId != '' && that.data.inputInfo.inputTitle != '' && that.data.inputInfo.inputSport != '' && that.data.inputInfo.inputDate != '' && that.data.inputInfo.inputNumber != '' && that.data.inputInfo.inputDescription != '' && that.data.value.campus != '' && that.data.value.venue != '' && that.data.value.startTime != '' && that.data.value.endTime != '') {
      var time = util.formatNow(new Date())
      var day = util.formatDate(new Date())
      console.log("当前时间：", day, time)
      if (parseInt(that.data.inputInfo.inputDate.substring(8, 10)) > parseInt(day.substring(8, 10)) || (parseInt(that.data.inputInfo.inputDate.substring(8, 10)) == parseInt(day.substring(8, 10)) && parseInt(that.data.value.startTime) > time[0])) {
        if ((parseInt(that.data.value.startTime) <= parseInt(that.data.value.endTime)) && (parseInt((that.data.value.startTime).substring(3)) <= parseInt((that.data.value.endTime).substring(3)))) {
          if (that.data.inputInfo.inputNumber >= that.data.currentnum) {
            wx.request({
              // 获取openid，发布活动
              url: 'http://101.132.69.33:2333/group/changeGroup/' + that.data.groupId,
              method: 'PUT',
              data: {
                "campus": that.data.value.campus,
                "desc": that.data.inputInfo.inputDescription,
                "endTime": that.data.value.endTime,
                "maxNum": parseInt(that.data.inputInfo.inputNumber),
                "sport": that.data.inputInfo.inputSport,
                "startTime": that.data.value.startTime,
                "title": that.data.inputInfo.inputTitle,
                "venue": that.data.value.venue,
                "wechatid": app.globalData.openId,
                "ymd": that.data.inputInfo.inputDate,
                "currentNum": that.data.currentnum
              },
              // 发布成功
              success: res => {
                console.log("修改-组团：", res)
                // 修改完成之后，提示修改成功并刷新全局数据
                if (res.statusCode == 200) {
                  if(res.data.response!="修改失败"){
                    Toast({
                      duration: 1300,
                      message: '修改成功！',
                    });
                    // 返回页面
                    setTimeout(function () {
                      wx.navigateBack({})
                    }, 1400);
                  }
                  else{
                    Toast({
                      duration: 1300,
                      message: '活动正在进行或已完成，不能修改了哦',
                    });
                  }                 
                } else {
                  Toast({
                    duration: 1300,
                    message: '服务器繁忙，请稍后再试！',
                  });
                }
              }
            })
          } else {
            Toast({
              duration: 1300,
              message: '活动人数不能少于现有参与人数哦',
            });
            console.log("参与人数有误")
          }
        } else {
          Toast({
            duration: 1300,
            message: '注意起止时间',
          });
          console.log("起止时间有误")
        }
      } else {
        Toast({
          duration: 1300,
          message: '活动时间离现在不能太近哦',
        });
        console.log("活动时间太近")
      }
    } else {
      Toast({
        duration: 1300,
        message: '请完善信息哦',
      });
      console.log("信息不完善")
    }
  },


  // bind changes in input
  changeStartTime: function(e) {
    this.setData({
      show03: true
    })
  },

  changeEndTime: function(e) {
    this.setData({
      show04: true
    })
  },

  changeNumber: function(e) {
    this.setData({
      'inputInfo.inputNumber': e.detail
    })
  },

  changeDescription: function(e) {
    this.setData({
      'inputInfo.inputDescription': e.detail
    })
  },

  // Picker03 04
  onChange0301(e) {
    this.setData({
      'value.startTime': e.detail.data.innerValue
    })
  },
  onChange0302(e) {
    this.setData({
      'value.endTime': e.detail.data.innerValue
    })
  },

  onCancel() {
    this.setData({
      show03: false,
      show04: false
    });
  },
})
// pages/publishCard/publishCard.js

import Toast from '../../dist/toast/toast';

const app = getApp()
const util = require('../../utils/util.js')

Page({

  data: {
    inputInfo: {
      'inputTitle': '',
      'inputSport': '',
      'inputDate': '',
      'inputNumber': '',
      'inputDescription': '',
      // 显示的地点
      'inputLocation': ''
    },
    value: {
      'campus': '',
      'venue': '',
      'startTime': '08:00',
      'endTime': '08:30'
    },

    // Picker01
    show01: false,
    index01: 0,
    columns01: [{
        values: Object.keys(app.globalData.places2),
        className: 'column1'
      },
      {
        values: Object.keys(app.globalData.places2['嘉定校区']),
        className: 'column2',
        defaultIndex: 0
      },
      {
        values: app.globalData.places2['嘉定校区']['自定义'],
        className: 'column3'
      }
    ],

    // Picker02
    show02: false,
    currentDate: new Date().getTime(),
    maxDate: new Date(new Date().getTime() + 168 * 2 * 60 * 60 * 1000).getTime(),

    // Picker03 04
    show03: false,
    show04: false
  },

  // when pages loads
  onLoad: function(options) {

  },

  // 删除按钮响应
  onDelete() {
    wx.navigateBack({
      // 返回之前页面
    })
  },

  // 发布按钮响应
  onPublish: function() {
    var that = this
    console.log("表单信息：", app.globalData.openId, that.data.inputInfo, that.data.value)
    // 判断表单信息是否完善
    if (app.globalData.openId != '' && that.data.inputInfo.inputTitle != '' && that.data.inputInfo.inputSport != '' && that.data.inputInfo.inputDate != '' && that.data.inputInfo.inputNumber != '' && that.data.inputInfo.inputDescription != '' && that.data.value.campus != '' && that.data.value.venue != '' && that.data.value.startTime != '' && that.data.value.endTime != '') {
      var time = util.formatNow(new Date())
      var day = util.formatDate(new Date())
      console.log("当前时间：", day, time)
      if (parseInt(that.data.inputInfo.inputDate.substring(8, 10)) > parseInt(day.substring(8, 10)) || (parseInt(that.data.inputInfo.inputDate.substring(8, 10)) == parseInt(day.substring(8, 10)) && parseInt(that.data.value.startTime) > time[0])) {
        if ((parseInt(that.data.value.startTime) <= parseInt(that.data.value.endTime)) && (parseInt((that.data.value.startTime).substring(3)) <= parseInt((that.data.value.endTime).substring(3)))) {
          wx.request({
            // 获取openid，发布活动
            url: 'http://101.132.69.33:2333/group/newGroup/',
            method: 'POST',
            data: {
              "campus": that.data.value.campus,
              "desc": that.data.inputInfo.inputDescription,
              "endTime": that.data.value.endTime,
              "maxNum": parseInt(that.data.inputInfo.inputNumber),
              "sport": that.data.inputInfo.inputSport,
              "startTime": that.data.value.startTime,
              "title": that.data.inputInfo.inputTitle,
              "venue": that.data.value.venue,
              "wechatid": app.globalData.openId,
              "ymd": that.data.inputInfo.inputDate,
              "currentNum": 1,
            },
            // 发布成功
            success: res => {
              console.log("增添-组团：", res)
              if (res.statusCode == 200) {
                if(res.data.response == '创建成功'){
                  // 修改完成之后，提示修改成功并刷新全局数据
                Toast({
                  duration: 1300,
                  message: '发布成功！',
                });
                // 返回页面
                setTimeout(function() {
                  wx.navigateBack({})
                }, 1400);
                } else {
                  Toast({
                    duration: 1500,
                    message: '所选场地似乎不符合活动时间=_=',
                  });
                }
              } else {
                Toast({
                  duration: 1300,
                  message: '服务器繁忙，稍后再试！',
                });
              }
            }
          })
        } else {
          Toast({
            duration: 1300,
            message: '注意起止时间',
          });
          console.log("起止时间有误")
        }
      } else {
        Toast({
          duration: 1300,
          message: '活动时间离现在不能太近哦',
        });
        console.log("活动时间太近")
      }
    } else {
      Toast({
        duration: 1300,
        message: '请完善信息哦',
      });
      console.log("信息不完善")
    }
  },


  // bind changes in input
  changeTitle: function(e) {
    this.setData({
      'inputInfo.inputTitle': e.detail
    })
  },

  changeSport() {
    this.setData({
      show01: true
    })
  },

  changeDate: function(e) {
    this.setData({
      show02: true
    })
  },

  changeStartTime: function(e) {
    this.setData({
      show03: true
    })
  },

  changeEndTime: function(e) {
    this.setData({
      show04: true
    })
  },

  changeNumber: function(e) {
    this.setData({
      'inputInfo.inputNumber': e.detail
    })
  },

  changeDescription: function(e) {
    this.setData({
      'inputInfo.inputDescription': e.detail
    })
  },

  // Picker01 场所与地点
  onConfirm01(event) {
    const {
      value,
      index
    } = event.detail;
    this.setData({
      show01: false,
      'inputInfo.inputSport': value[2],
      'inputInfo.inputLocation': value[0] + ((value[1] != '自定义') ? value[1] : ''),
      'value.campus': value[0],
      'value.venue': value[1]
    })
  },

  onChangeSport(e) {
    const {
      picker,
      value,
      index
    } = e.detail;
    picker.setColumnValues(1, Object.keys(app.globalData.places2[value[0]]));
    picker.setColumnValues(2, app.globalData.places2[value[0]][value[1]]);
  },

  // Picker02
  onConfirm02(e) {
    this.setData({
      show02: false,
      'inputInfo.inputDate': util.formatDate(new Date(e.detail)),
      // 'value.date': e.detail
    })
  },

  // Picker03 04
  onChange0301(e) {
    this.setData({
      'value.startTime': e.detail.data.innerValue
    })
  },
  onChange0302(e) {
    this.setData({
      'value.endTime': e.detail.data.innerValue
    })
  },

  onCancel() {
    this.setData({
      show01: false,
      show02: false,
      show03: false,
      show04: false
    });
  },
})
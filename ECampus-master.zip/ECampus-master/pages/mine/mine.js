// pages/mine/mine.js

const app = getApp()

Page({
  data: {
    // userInfo
    userInfo: {},
    tag: '参加运动获取标签',
    hasRead: true,
    notiNum: 0,
    notinum: 0
  },

  // datas needs to refresh
  onShow: function() {
    var that = this
    // 获取用户信息
    if (app.globalData.loginStatus) {
      that.setData({
        userInfo: app.globalData.userInfo
      })
      console.log("用户信息：", that.data.userInfo, app.globalData.avatarUrl)
      // 标签控制
      if (that.data.userInfo.tag) {
        that.setData({
          tag: that.data.userInfo.tag
        })
        console.log("标签控制：", that.data.tag)
      }
      that.checkNotice()
    }
  },

  // check notification
  checkNotice: function() {
    var that = this
    // wx.request({
    //   url: 'http://101.132.69.33:2333/noti/getNotiByWId/' + app.globalData.openId,
    //   success: res => {
    //     console.log("通知信息：", res.data)
    //     if (res.data == '' || that.data.notiNum == res.data.length) {
    //       that.setData({
    //         hasRead: true,
    //         notinum: res.data.length
    //       })
    //     } else if (that.data.notiNum != res.data.length) {
    //       that.setData({
    //         hasRead: false,
    //         notinum: res.data.length
    //       })
    //     }
    //   }
    // })
    wx.request({
      url: 'http://101.132.69.33:2333/noti/getReadByWId/' + app.globalData.openId,
      success: res => {
        console.log("是否有通知：", res.data)
        if(res.data.response == '有未读') {
          that.setData({
            hasRead: false
          })
        }
      }
    })
  },

  // page functions
  onClickAvatar: function() {
    wx.navigateTo({
      url: '../editInfo/editInfo',
    })
  },

  onClickCollection: function() {
    wx.switchTab({
      url: '../myGroup/myGroup',
    })
  },

  onClickNotice: function() {
    this.setData({
      hasRead: true,
      notiNum: this.data.notinum
    })
    wx.navigateTo({
      url: '../noticeList/noticeList',
    })
  },

  onClickSettings: function() {
    wx.navigateTo({
      url: '../notice/notice',
    })
  },
})
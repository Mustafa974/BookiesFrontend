// pages/myGroup/myGroup.js

import Toast from '../../dist/toast/toast';

const app = getApp()
export default {
  data() {
    return {
      active: 2
    };
  }
};

Page({

  /**
   * 页面的初始数据
   */
  data: {
    myCardInfo:{

    },

    // CardInfo
    cardInfo: {
      pubImg: "../../assets/images/user.jpg",
      groupId: 1,
      cardTitle: "嘉园杯羽毛球",
      cardPlace: "嘉定校区",
      cardVenue: "体育中心",
      cardSport: "羽毛球",
      cardStartTime: "08:00",
      cardNum: 4,
      cardSum: 8,
      //is collected
      collected: 0,
      //stateGroup
      state: 0,
      pubTime: "18-12-25",
    },

  },

  //collect
  onCollect(event) {
    if (this.data.cardInfo.collectColor == '#BEBEBE') {
      this.setData({
        'cardInfo.collectColor': '#FFD700',
        collected: 1
      });
      Toast('已收藏~');
    } else {
      this.setData({
        'cardInfo.collectColor': '#BEBEBE',
        collected: 0
      });
      Toast('取消收藏');
    }
    // console.log(this.data.collected);
  },

  // toPages
  toPage: function (e) {
    var groupId = e.currentTarget.dataset.groupid
    console.log(e.detail);
    wx.navigateTo({
      url: '../activityCard/activityCard?groupId=' + groupId,
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // this.loadMyGroup()
    // this.loadCollecData()
  },

  //load my collected group list
  loadCollecData: function () {
    var that = this
    var wechaId = app.globalData.openId
    wx.request({
      url: 'http://101.132.69.33:2333/collect/showAllCollect/' + wechaId,
      success: res => {
        var info = res.data
        that.setData({
          cardInfo: info
        })
        console.log('loadCollecData我的收藏')
        console.log(res)
      }
    })
  },
  //load my group list
  loadMyGroup:function(){
    var that = this
    var wechaId = app.globalData.openId
    wx.request({
      url: 'http://101.132.69.33:2333/joinGroup/getJGList/' + wechaId,
      success: res => {
        var info = res.data
        that.setData({
          myCardInfo: info
        })
        console.log('loadMyGroup我的参团')
        console.log(that.data.myCardInfo)
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.loadMyGroup()
    this.loadCollecData()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  onClose(event) {
    const { position, instance } = event.detail;
    switch (position) {
      case 'left':
      case 'cell':
        instance.close();
        break;
      case 'right':
        Dialog.confirm({
          message: '确定删除吗？'
        }).then(() => {
          instance.close();
        });
        break;
    }
  }
})
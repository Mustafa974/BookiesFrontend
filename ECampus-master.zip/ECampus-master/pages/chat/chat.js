// pages/chat/chat.js

import Toast from '../../dist/toast/toast';

const app = getApp()
const websocket = require('../../utils/websocket.js');
const utils = require('../../utils/util.js');

Page({
  // data
  data: {
    groupId: '',
    newslist: {},
    userInfo: {},
    scrollTop: 0,
    message: "",
    height: 0
  },

  // load history messages
  onLoad: function(options) {
    var that = this
    that.setData({
      groupId: options.groupId,
      userInfo: app.globalData.userInfo,
      'userInfo.avatarUrl': app.globalData.avatarUrl,
      'userInfo.wechatID': options.wechatId
    })
    console.log("进入聊天室，用户信息：", that.data.userInfo, "用户微信号：", options.wechatId)
    // load history messages
    that.load()
    // connect to server
    websocket.connect(that.data.groupId, options.wechatId, function(res) {
      console.log("websocket.connect | 添加数据 ", res.data)
      var list = that.data.newslist
      list.push(JSON.parse(res.data))
      that.setData({
        newslist: list,
      })
    })
    // 返回底部
    that.toBottom()
  },

  // unload
  onUnload() {
    wx.closeSocket();
    console.log("连接已断开")
  },

  // page functions

  // load messages

  load: function() {
    var that = this
    wx.request({
      url: 'http://101.132.69.33:2333/message/getMessageList/' + that.data.groupId,
      success: res => {
        // console.log("返回的历史消息：", res.data)
        if (res.data != '') {
          console.log("历史消息不为空：", res.data)
          that.setData({
            newslist: res.data
          })
        } else {
          console.log("历史消息为空")
        }
      }
    })
  },

  // send button
  send: function() {
    var that = this
    if (that.data.message.trim() == "") {
      Toast({
        duration: 1300,
        message: '消息不能为空',
      });
    } else {
      var time = utils.formatTime(new Date())
      // socket 连接与数据发送
      websocket.send('{' + '"content": "' + that.data.message + '", "sendTime": "' + time + '", "name": "' + that.data.userInfo.name + '", "avatar": "' + that.data.userInfo.avatarUrl + '", "wechatID": "' + that.data.userInfo.wechatID + '", "groupID": "' + that.data.groupId + '"' + '}')
      // 连接数据库储存
      wx.request({
        url: 'http://101.132.69.33:2333/message/addMessage',
        method: 'POST',
        data: {
          "content": that.data.message,
          "sendTime": time,
          "name": that.data.userInfo.name,
          "avatar": that.data.userInfo.avatarUrl,
          "wechatID": that.data.userInfo.wechatID,
          "groupID": that.data.groupId,
        },
        success: res => {
          console.log("储存消息返回的res：", res.data)
          console.log("此时的newslist：", Object.keys(that.data.newslist).length)
          // bug fix?
          if (Object.keys(that.data.newslist).length == 0) {
            console.log("标记：第一次发送")
            that.load()
          }
          // 发送完消息，返回底部
          that.toBottom()
        }
      })
    }
  },

  // input value
  bindChange(res) {
    this.setData({
      message: res.detail.value
    })
  },

  // clear input
  cleanInput() {
    // button会自动清空，所以不能再次清空而
    // 应该给他设置目前的input值
    this.setData({
      message: this.data.message
    })
  },

  // 聊天消息始终显示最底端
  toBottom: function() {
    const query = wx.createSelectorQuery()
    query.select('#flag').boundingClientRect()
    query.selectViewport().scrollOffset()
    query.exec(function(res) {
      wx.pageScrollTo({
        scrollTop: res[0].bottom, // #the-id节点的下边界坐标  
        success: console.log("滚动")
      })
      res[1].scrollTop // 显示区域的竖直滚动位置  
    })
  },
})
// pages/activityCard/activityCard.js

import {
  $wuxDialog
} from '../../wux/index'
import Toast from '../../dist/toast/toast';

const app = getApp()

Page({
  // data
  data: {
    option: '',
    groupId: '',
    pubWechatId:'',//发布者wechatId
    cardImg: '',
    cardTitle: "嘉园杯羽毛球比赛",
    collected: false,
    state: 1,
    stateGroup: '未开始',
    cardData: '',
    cardStartTime: '8:00',
    cardEndTime: '10:00',
    cardPlace: "嘉定校区",
    cardVenue: "体育中心",
    cardSport: '羽毛球',
    cardPeople: '8',
    cardNotes: '有没有约羽毛球的小伙伴组团呀？早上八点嘉定新体育馆',
    joinPeople: ["../../assets/images/user.jpg"],
    pubTime: '2018-12-25',
    pubMember: "",
    //查看组团卡片者角色
    groupRole: 1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    that.setData({
      option: options
    })
    that.loadData(options)
  },

  onShow: function(){
    this.loadData(this.data.option)
  },

  // 加载数据
  loadData: function(detail) {
    var that = this;
    wx.request({
      url: 'http://101.132.69.33:2333/getGroupDetail/getGroupDetail/' + app.globalData.openId + '/' + detail.groupId,
      success: res => {
        var info = res.data
        that.setData({
          groupId: detail.groupId,
          pubWechatId: info.leaderWechatID,
          cardImg: info.avatar,
          cardTitle: info.title,
          collected: info.collected,
          state: info.status,
          cardData: info.date,
          cardStartTime: info.startTime,
          cardEndTime: info.endTime,
          cardPlace: info.campus,
          cardVenue: info.venue,
          cardSport: info.sport,
          cardPeople: info.numOfPeople,
          cardNotes: info.comments,
          joinPeople: info.memberList,
          pubTime: info.createdTime,
          //查看组团卡片者角色
          groupRole: info.role
        })
        console.log("卡片信息加载：", info)
      }
    })
  },

  getUser(wechatId){
    if (wechatId != app.globalData.openId) {
      wx.navigateTo({
        url: '../userHome/userHome?wechatId=' + wechatId,
        // success: function (res) { },
        // fail: function (res) { },
        // complete: function (res) { },
      })
    }
    else {
      wx.switchTab({
        url: '../mine/mine',
      })
    }
  },

  // 下拉刷新
  onPullDownRefresh: function() {
    this.loadData(this.data.option)
  },

  // 分享
  onShareAppMessage: function() {
    // if (!this.data.id) {
    //   // todo 返回默认分享信息，比如小程序首页
    // }
    // return {
    //   title: 'xxx',
    //   path: 'xxx?id=' + this.data.id,
    //   success: function(res) {
    //     if (this.data.savedId === this.data.id) {
    //       return;
    //     }
    //     this.saveData().then(() => {
    //       this.setData({
    //         savedId: this.data.id
    //       });
    //       // todo 如果跳转到其他页面，删除this.data.id
    //     });
    //   }
    // };
  },

  //collect
  onCollect(event) {
    var that = this
    var wechaId = app.globalData.openId
    if (this.data.collected == false) {
      wx.request({
        url: 'http://101.132.69.33:2333/collect/addCollect/' + wechaId + '/' + that.data.groupId,
        method: 'POST',
        data: {
          'wechatId': wechaId,
          'groupId': that.data.groupId
        },
        success: res => {
          var info = res.data
          console.log(info)
          if(info.response!="收藏失败"){
            this.setData({
              collectColor: '#FFD700',
              collected: true
            });
            Toast('已收藏~');
          }
          else{
            Toast('组团已经开始或已完成，不能收藏啦～')
          }
        }
      })
    } else {
      this.setData({
        collectColor: '#BEBEBE',
        collected: 0
      });
      Toast('取消收藏');
      wx.request({
        url: 'http://101.132.69.33:2333/collect/deleteCollect/' + wechaId + '/' + that.data.groupId,
        method: 'DELETE',
        data: {
          'wechatId': wechaId,
          'groupId': that.data.groupId
        },
        success: res => {
          var info = res.data
          console.log(info)
        }
      })
    }
    // console.log(this.data.collected);
  },

  // 设置运动前提醒
  notify() {
    $wuxDialog().confirm({
      resetOnClose: true,
      closable: true,
      title: '设置提醒',
      content: '将在组团开始前15分钟提醒你',
      onConfirm(e) {
        console.log('确定提醒')
      },
      onCancel(e) {
        console.log('不提醒')
      },
    })
  },

  //查看发布者用户信息
  getPubUser(){
    var wechatId = this.data.pubWechatId
    // ...
    this.getUser(wechatId)
  },
  //查看参团者信息
  getGroupUser(e){
    var wechatId = e.currentTarget.dataset.wechatid
    this.getUser(wechatId)
  },

  // 跳转运动场地界面
  toVenue() {
    var location = this.data.cardPlace
    var venue = this.data.cardVenue
    var sport = this.data.cardSport
    console.log(location + venue + sport)
    wx.navigateTo({
      url: '../mainCard/mainCard?location=' + location + '&venue=' + venue + '&sport=' + sport,
    })
  },

  // 进入聊天室
  joinChat() {
    var wechatId = app.globalData.openId
    wx.navigateTo({
      url: '../chat/chat?groupId=' + this.data.groupId + '&wechatId=' + wechatId,
    })
  },

  // 参加组团
  joinGroup(event) {
    var that = this
    var wechaId = app.globalData.openId
    $wuxDialog().confirm({
      resetOnClose: true,
      closable: true,
      title: '参加组团',
      content: '你确定要参加组团吗？',
      onConfirm(e) {
        // 发送请求
        wx.request({
          url: 'http://101.132.69.33:2333/joinGroup/join/' + wechaId + '/' + that.data.groupId,
          method: 'POST',
          data: {
            'wechatId': wechaId,
            'groupId': that.data.groupId
          },
          success: res => {
            var info = res.data
            console.log('参加组团')
            console.log(info)
            if (info.response !="加入失败"){
              // 发送服务消息
              that.setNotice(event, that)
              Toast({
                duration: 1300,
                message: '参团成功',
              });
              setTimeout(function () {
                that.loadData(that.data.option)
              }, 1300);
            }
            else{
              Toast({
                // duration: 1300,
                message: '已满团～可先收藏，等待可能有人退团或人数扩增哦！',
              });
            }            
          }
        })
      },
      onCancel(e) {
        // console.log('取消操作')
      },
    })
  },

  //退出组团
  exitGroup: function() {
    var that = this
    var wechaId = app.globalData.openId
    wx.request({
      url: 'http://101.132.69.33:2333/joinGroup/quit/' + wechaId + '/' + that.data.groupId,
      method: 'DELETE',
      data: {
        'wechatId': wechaId,
        'groupId': that.data.groupId
      },
      success: res => {
        var info = res.data
        if(info.response!="退出失败"){
          //返回上一级页面
          Toast({
            duration: 1300,
            message: '退出组团',
          });
          setTimeout(function () {
            wx.navigateBack({
              delta: 2,
            });
          }, 1400);
          console.log("退团成功返回：")
          console.log(info)
        }
        else{
          Toast({
            duration: 1300,
            message:'组团正在进行中，不能退出哦～',
          });
          console.log("退团失败返回：")
          console.log(info)
        }
      }
    })
  },

  // 编辑组团
  editGroup: function() {
    console.log('编辑组团信息')
    wx.navigateTo({
      url: '../editCard/editCard?groupId=' + this.data.groupId,
    })
  },

  // 提示组团退出
  exitConfirm() {
    var that = this
    $wuxDialog().confirm({
      resetOnClose: true,
      closable: true,
      title: '退出参团',
      content: '你确定要退出该团吗？',
      onConfirm(e) {
        that.exitGroup()
      },
      onCancel(e) {
        // console.log('取消操作')
      },
    })
  },

  // set notice
  // 设置组团成功提醒
  setNotice: function(e, that) {
    // var that = this
    console.log("获取formID：", e.detail)
    wx.request({
      url: 'https://api.weixin.qq.com/cgi-bin/token',
      method: 'GET',
      data: {
        grant_type: 'client_credential',
        appid: 'wxd10cf7349d4d29d3',
        secret: 'b3cce29c050d603738df811d1f3dc8ab'
      },
      success: res => {
        // set token
        console.log("token信息: ", res.data, res.data.access_token)
        app.globalData.token = res.data.access_token
        // form the notification
        wx.request({
          url: 'https://api.weixin.qq.com/cgi-bin/message/wxopen/template/send?access_token=' + app.globalData.token,
          method: 'POST',
          header: {
            'content-type': 'application/json' // 默认值
          },
          data: {
            "touser": app.globalData.openId,
            "template_id": "fqBp0uUzyfSC-nFDO07-WApv8tgGFsxzHN_36vOqFOw",
            "page": "pages/login/login",
            "form_id": e.detail.formId,
            "data": {
              "keyword1": {
                "value": that.data.cardTitle
              },
              "keyword2": {
                "value": that.data.cardData + ' ' + that.data.cardStartTime
              },
              "keyword3": {
                "value": that.data.cardPlace + that.data.cardVenue
              },
              "keyword4": {
                "value": that.data.cardNotes
              }
            },
            "emphasis_keyword": "keyword1.DATA"
          },
          success: res => {
            console.log("服务消息：", res)
          }
        })
      }
    })
  }
})
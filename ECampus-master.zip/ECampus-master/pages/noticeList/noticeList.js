// pages/noticeList/noticeList.js

const app = getApp()

Page({

  // datas
  data: {
    notifications: []
  },

  // when page loads
  onLoad: function (options) {
    var that = this
    // 标记已读
    wx.request({
      url: 'http://101.132.69.33:2333/noti/setReadByWId/' + app.globalData.openId,
      success: res => {
        console.log("标记通知：", res.data)
      }
    })
    // 获取通知
    wx.request({
      url: 'http://101.132.69.33:2333/noti/getNotiByWId/' + app.globalData.openId,
      success: res => {
        if (res.data != '') {
          var receive = res.data
          for(var i = 0; i < receive.length; i++){
            receive[i].notitime = receive[i].notitime.substring(0,10)
          }
          that.setData({
            notifications: receive
          })
          console.log("本地通知：", that.data.notifications)
        }
      }
    })
  },
})
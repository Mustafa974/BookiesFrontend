// pages/notice/notice.js

import Toast from '../../dist/toast/toast';

const app = getApp()

Page({

  // datas
  data: {
    input: ''
  },

  // page functions
  onChange: function(e) {
    // console.log(e)
    this.setData({
      input: e.detail
    })
  },

  onPublish: function() {
    if (app.globalData.openId == 'o5GWH5OrBLj934ldbgQjL9ouTAko' || app.globalData.openId == 'o5GWH5Ib2RCpYdVtSDBxOfRtT0_c' || app.globalData.openId == 'o5GWH5NvJrweOarPvhCsR4Omw_BQ' || app.globalData.openId == 'o5GWH5DFCMiTseAPfVsKV5EjXjNE') {
      if (this.data.input != '') {
        wx.request({
          url: 'http://101.132.69.33:2333/noti/newNoti',
          method: 'POST',
          data: {
            'content': this.data.input,
            'wechatId': 'all'
          },
          success: res => {
            console.log("发布通知：", res)
            if (res.statusCode == 200) {
              Toast({
                duration: 1300,
                message: '发布成功',
              });
              setTimeout(function() {
                wx.navigateBack({})
              }, 1400);
            } else {
              Toast({
                duration: 1300,
                message: '服务器繁忙，稍后再试',
              });
            }
          }
        })
      } else {
        Toast({
          duration: 1300,
          message: '通知内容不能为空'
        });
      }
    } else {
      Toast({
        duration: 1300,
        message: '非管理员操作'
      });
      setTimeout(function() {
        wx.navigateBack({})
      }, 1400);
    }
  }
})
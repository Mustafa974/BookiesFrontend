// pages/mainCard/mainCard.js

const app = getApp();

var util = require("../../utils/util.js");
var url = "http://101.132.69.33:2333/viewInfo/getDetailed/{venue}/{sport}/{campus}"

Page({

  /**
   * Page initial data
   */
  data: {

    date: "",
    open:false,
    cardTitle: "嘉定校区新体育馆",
    cardLocation: "篮球",
    cardDescription: "嘉定羽毛球馆，一般白天是用作乒乓球和羽毛球上课的地方，下午和晚上会有租用活动～～每小时也不贵，凭学生证也不贵。",
    cardStartTime: "08:00",
    cardEndTime: "20:00",
    latitude: 31.289870,
    longitude: 121.216090,
    markers: [{
      iconPath: '../../assets/images/map_maker.png',
      id: 0,
      latitude: 31.289870,
      longitude: 121.216090,
      width: 50,
      height: 50
    }],
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function(options) {
    // console.log(options)
    this.loaddata(options)
    var DATE = util.formatDate(new Date());
    this.setData({
      date: DATE,
    });
  },
  // load detail venue and sport
  loaddata: function(detail) {
    console.log(detail)
    var that = this
    that.setData({
      cardTitle: detail.location +detail.venue,
      cardLocation: detail.sport,
    })
    wx.request({
      url: 'http://101.132.69.33:2333/viewInfo/getDetailed/' + detail.venue + '/' + detail.sport + '/' + detail.location,
      success(res) {
        var info = res.data[0]
        that.setData({
          cardStartTime:info.startTime,
          cardEndTime: info.endTime,
          cardDescription: info.cost + info.appointment + info.comments,
          open:info.open,
          latitude: info.longitude ,
          longitude: info.altitude,
          markers: [{
            iconPath: '../../assets/images/map_maker.png',
            id: 0,
            latitude: info.longitude,
            longitude: info.altitude,
            width: 48,
            height: 48
          }],
        })
        // console.log(info)
        console.log(that.data.markers)
      }
    })
  },
  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function() {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function() {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function() {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function() {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function() {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function() {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function() {

  }
})
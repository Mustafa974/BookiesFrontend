// pages/main/main.js

//获取应用实例
const app = getApp()
const allInfoUrl ='http://101.132.69.33:2333/viewInfo/getInfoByScreened/'
Page({
  // initial datas
  data: {

    // Title01
    selectedLocation: '嘉定校区',
    show01: false,
    index01: 1,
    columns01: ['嘉定校区', '四平校区'],

    // Title02
    selectedSport: '全部运动',
    show02: false,
    index02: 0,
    columns02: ['全部运动', '足球', '篮球', '游泳', '羽毛球', '网球', '高尔夫', '乒乓球', '台球', '跑步', '排球', '橄榄球', '健身', '攀岩'],

    // Weather
    cityCodes: ['310113', '310110'],
    cityCode: '310113',
    weatherInfo: '天气数据查询异常',
    weatherSrc: '../../assets/images/weather_sunny.png',

    // CardInfo
    cardInfo: {
      // cardTitle: "新体育馆",
      // cardSubTitle: "篮球 | 乒乓球 | 羽毛球",
      // cardStartTime: "08:00",
      // cardEndTime:"10:00"
    },

    state: true,
  },

  //  pages functions start
  onLoad: function(options) {
    var that = this;
    // get weather
    that.checkWeather();
    // get initial cards
    that.loadData();

  },

  onPullDownRefresh: function() {

  },

  onShareAppMessage: function() {

  },
  // pages functions end

  // functions start
  checkWeather: function() {
    wx.request({
      url: app.globalData.weatherUrl + this.data.cityCode,
      success: res => {
        var status = res.data.status
        if (status == '1') {
          var weather = res.data.lives[0].weather
          var temp = res.data.lives[0].temperature
          var weather_info = weather + ' ' + temp + '°'
          var weather_src = ''
          if (weather.indexOf("晴") != -1) {
            weather_src = app.globalData.weatherSrc + 'sunny.png'
          } else if (weather.indexOf("云") != -1) {
            weather_src = app.globalData.weatherSrc + 'sunny_cloudy.png'
          } else if (weather.indexOf("阴") != -1) {
            weather_src = app.globalData.weatherSrc + 'cloudy.png'
          } else if (weather.indexOf("风") != -1) {
            weather_src = app.globalData.weatherSrc + 'windy.png'
          } else if (weather.indexOf("雨") != -1) {
            weather_src = app.globalData.weatherSrc + 'rainy.png'
          } else if (weather.indexOf("雪") != -1) {
            weather_src = app.globalData.weatherSrc + 'snowy.png'
          } else {
            weather_src = app.globalData.weatherSrc + 'frogy.png'
          }
          this.setData({
            weatherInfo: weather_info,
            weatherSrc: weather_src
          })
        }
      }
    })
  },
  // functions end

  // load venue and sport
  loadData: function() {
    var that = this
    wx.request({
      url: 'http://101.132.69.33:2333/viewInfo/getInfoByScreened/' + that.data.selectedLocation + '/' + that.data.selectedSport,
      success(res) {
        var info = res.data
        that.setData({
          cardInfo: info
        })
        // console.log(that.data.cardInfo)
      }
    })
  },

  // wxml functions start
  button_click: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },

  bindPickerChange(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },

  onClose() {
    this.setData({
      show: false
    });
  },

  // Title01
  //
  onClick01() {
    this.setData({
      show01: true,
      // 'cardInfo.cardTime' : 'haha'
    });
  },

  onConfirm01(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    console.log(event.detail);
    this.setData({
      show01: false,
      selectedLocation: this.data.columns01[index],
      cityCode: this.data.cityCodes[index]
    })
    // recheck the weather
    this.checkWeather();
    // get cards
    this.loadData();
  },

  // Title02
  //
  onClick02() {
    this.setData({
      show02: true
    });
  },

  onConfirm02(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    // Toast(`当前值：${value}, 当前索引：${index}`);
    this.setData({
      show02: false,
      selectedSport: this.data.columns02[index]
    })
    // get cards
    this.loadData();
  },

  onCancel0102() {
    this.setData({
      show02: false,
      show01: false
    });
  },

  // toPages
  toPage(event) {
    var location = this.data.selectedLocation
    var venue = event.currentTarget.dataset.venue
    var sport = event.currentTarget.dataset.sport
    console.log(location + venue + sport)
    wx.navigateTo({
      url: '../mainCard/mainCard?location='+location+'&venue='+venue+'&sport='+sport,
    })
  },

  // toCaiyun
  toCaiyun: function() {
    wx.navigateTo({
      url: '../weather/weather',
    })
  }
  // wxml functions end
})